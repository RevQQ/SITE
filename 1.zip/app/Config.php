<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Config extends Model
{
    protected $fillable = [
        'title', 'description', 'keywords', 'dollar', 'max_items', 'profit', 'payment_to_withdraw', 'market_api_key', 'coef_price',
        'site_name', 'vk_group', 'freekassa_id', 'freekassa_secret_1', 'freekassa_secret_2', 'freekassa_sum', 'skinpay_sum', 'percent_referral',
        'bots_bets', 'bots_min', 'bots_max', 'bots_min_count', 'bots_max_count', 'bots_chat', 'min_withdraw'
    ];
}
