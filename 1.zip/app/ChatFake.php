<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ChatFake extends Model
{
    protected $fillable = [
        'text'
    ];
}
